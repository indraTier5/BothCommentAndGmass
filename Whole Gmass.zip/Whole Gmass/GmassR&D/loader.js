// This file will get downloaded and run by your extension making it easy to update
// Don't forget to add this domain to your manifest.json!

var d = new Date();
var n = d.getMilliseconds();

InboxSDK.loadScript('https://www.gmass.co/Extension2019/gmass.js?x=' + n.toString())